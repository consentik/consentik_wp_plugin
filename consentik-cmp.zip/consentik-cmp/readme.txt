=== Consentik CMP – GDPR/CCPA Cookie Consent Banner ===
Contributors: consentik
Donate link: https://consentik.com/
Tags: gdpr, cookie banner, consentik, cookie consent, ccpa
Requires at least: 6.0
Tested up to: 6.9
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Easily integrate Consentik Cookie Banner into your WordPress site to comply with GDPR, CCPA, and Google Consent Mode v2.
== Description ==
Consentik CMP is a powerful solution tailored for WordPress to help you manage cookie consent effortlessly. This plugin allows you to integrate the Consentik Cookie Banner into your website by simply entering your Site ID and Instance ID.
**Why use Consentik?**
*   **Compliance**: Ready for GDPR, CCPA, and global privacy laws.
*   **Google Certified**: Fully supports Google Consent Mode v2.
*   **Easy Setup**: No coding required. Just register, get your IDs, and you are good to go.
To get your **Site ID** and **Instance ID**, please register a free account at [Consentik CMP](https://cmp.consentik.com/register).
== Installation ==
1.  Upload the plugin files to the `/wp-content/plugins/consentik-cookie-banner` directory, or install the plugin through the WordPress plugins screen directly.
2.  Activate the plugin through the 'Plugins' screen in WordPress.
3.  Go to **Settings > Consentik CMP** to configure the plugin.
4.  Enter your **Site ID** and **Instance ID** obtained from your Consentik dashboard.
5.  Click **Save Changes**. The banner will now appear on your site.
== Frequently Asked Questions ==
= Where do I find my Site ID and Instance ID? =
You need to create an account at [https://cmp.consentik.com/register](https://cmp.consentik.com/register). After logging in, create a new site configuration, and you will find these IDs in your dashboard script section.
= Does this plugin support Google Consent Mode v2? =
Yes, Consentik CMP is fully compatible with Google Consent Mode v2 requirements.
== Screenshots ==
1.  **Settings Page**: Easily enter your Site ID and Instance ID.
2.  **Banner Preview**: Example of how the cookie banner looks on the frontend.
== Changelog ==
= 1.0.0 =
*   Initial release.
== Upgrade Notice ==
= 1.0.0 =
This is the first version of Consentik CMP plugin.